
const countries = [
  'Albania',
  'Bolivia',
  'Canada',
  'Denmark',
  'Ethiopia',
  'Finland',
  'Germany',
  'Hungary',
  'Ireland',
  'Japan',
  'Kenya'
]






// Add "-" after every even number
const numbers = "315469781318158";





// Find odd numbers
 var arr = [5, 24, 122, 625, 3125, 15625];
 