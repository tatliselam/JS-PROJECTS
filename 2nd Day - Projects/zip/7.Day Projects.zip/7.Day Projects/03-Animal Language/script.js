//Convert any text to whale language! 

let input = 'Hi, Human!';

