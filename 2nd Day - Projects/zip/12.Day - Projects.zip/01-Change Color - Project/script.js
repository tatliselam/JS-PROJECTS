//Choose a random color
const colors = ['red', 'green', 'blue', 'yellow', 'pink', 'purple'];
