function fibonacciGen (num) {
 

}


function fibonacciFinder (num) {
    
}



