## Tip Calculator

John and his family went on a holiday and went to different restaurants. The bills were $124, $48, $75 and $268.
To tip the waiter a fair amount, John created a simple tip calculator (as a function). He likes to tip 20% of the bill when the bill is less than $50, 15% when the bill is between $50 and $200, and 10% if the bill is more than $200.