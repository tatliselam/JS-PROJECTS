## Study Hard Calculator

The program will determine the actual and ideal hours of study for each day of the last week.
Finally, it will calculate, in hours, how far you are from your weekly study goal.
