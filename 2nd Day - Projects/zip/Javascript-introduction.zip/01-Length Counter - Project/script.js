
const calculateCharacter = () =>{

    

}


// Invoke the function when button is clicked

btn.addEventListener('click', calculateCharacter);
